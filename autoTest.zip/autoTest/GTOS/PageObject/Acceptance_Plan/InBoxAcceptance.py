import time

import pytest_check as check
from Base.basepage import BasePage
from GTOS.Controls.text import Gtos_text
from GTOS.Config import config
from GTOS.Controls.Gtos_table import Gtos_table


class InBox_Acceptance(BasePage):
    """
    计划受理--安排计划--进箱受理
    """
    def choice_tree_straight(self,input):
        """
        选择计划类型-直装类型
        """
        self.logger.info('步骤1：选择计划类型')
        self.click('xpath',f"//span[text()='安排{input['贸易类型']}箱直装计划']")

    def select_value(self,input):
        """
        选择进口船、提单号
        """
        self.logger.info('步骤2：输入航名航次')
        Gtextinput = Gtos_text(self.driver)
        Gtextinput.select_by_placeholder('请选择',input['船名航次'])

    def addPlan(self,input):
        """
        新增进场计划
        """
        try:
            self.logger.info('步骤3：新增进场计划箱')
            self.click('xpath',"(//span[text()='新增'])[1]")
            self.waitloading()
            Gtextinput = Gtos_text(self.driver)
            Gtextinput.input_by_label('箱号', config.boxNumber)
            Gtextinput.input_by_label('铅封号', 'A123')
            Gtextinput.select_by_label('尺寸', input['尺寸'])
            Gtextinput.select_by_label('箱型', input['箱型'])
            Gtextinput.select_by_label('箱高', input['箱高'])
            Gtextinput.select_by_label('持箱人', input['持箱人'])
            Gtextinput.input_by_label('箱货总重', input['箱货总重'])
            Gtextinput.select_by_label('卸货港', input['卸货港'])
            Gtextinput.select_by_label('目的港', input['目的港'])
            self.save()
            self.check_alert('保存成功')
            tablecheck = Gtos_table(self.driver)
            self.logger.info('步骤4：校验字段')
            check.equal(tablecheck.get_value('箱号'), config.boxNumber)
            check.equal(tablecheck.get_value('贸易类型'), '内贸')
            check.equal(tablecheck.get_value('铅封号'), 'A123')
            check.equal(tablecheck.get_value('尺寸'), input['尺寸'])
            check.equal(tablecheck.get_value('箱型'), input['箱型'])
            check.equal(tablecheck.get_value('持箱人'), input['持箱人'])
            check.equal(tablecheck.get_value('箱高'), input['箱高'])
            check.equal(tablecheck.get_value('箱货总重'), input['箱货总重'])
            check.equal(tablecheck.get_value('卸货港'), input['卸货港'])
            check.equal(tablecheck.get_value('目的港'), input['目的港'])
        except:
            self.cancel()

    def Add_value(self):
        """
        新增货信息
        """
        try:
            self.logger.info('步骤5：新增货信息')
            self.click('xpath', "(//span[text()='新增'])[2]")
            time.sleep(1)
            Gtextinput = Gtos_text(self.driver)
            Gtextinput.input_by_label('提单号', config.boxNumber)
            self.save()
            self.check_alert('保存成功')
            tablecheck = Gtos_table(self.driver,2)
            self.logger.info('步骤6：校验字段')
            check.equal(tablecheck.get_value('提单号'), config.boxNumber)
        except:
            self.cancel()

    def build_plan(self):
        """
        生产计划
        """
        self.logger.info('步骤7：生成计划')
        self.click('xpath',"//span[text()='生成计划']")
        Gtextinput = Gtos_text(self.driver)
        Gtextinput.select_by_label('申请人','AHCH')
        Gtextinput.select_by_label('流向/来源','1205')
        Gtextinput.element_wait_disappear("xpath","//div[@role='alert']//p")
        self.click('xpath',"//button/span[contains(text(),'保存')]")
        self.check_alert('计划保存成功')


    def process(self,input):
        """
        进箱直提受理流程
        """
        self.choice_tree_straight(input)
        self.select_value(input)
        self.addPlan(input)
        self.Add_value()
        self.build_plan()
