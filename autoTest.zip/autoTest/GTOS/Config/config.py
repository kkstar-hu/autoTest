from Commons.RandomFunction import CommonGenerator

host="http://10.166.0.155/app/#/login"
#进场计划箱号
global boxNumber
#boxNumber=CommonGenerator.generate_spec("JXNU",7)
boxNumber="JXNU000020"
takeNumber="1014" #进箱提单号
username="admin"
password="ctos@12345"
showname="管理员"
createName="8540/胡康莉"